/**
 * This class checks if Quad is a valid hand or not. This quad hand consists of five cards, with four having the same rank
 * @author trishagupta
 *
 */
public class Quad extends Hand
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param player
	 * @param cards
	 */
	public Quad(CardGamePlayer player, CardList cards)
    {
        super(player, cards);
    }
   
   
   
/**
 * return Hand#isValid()
 */
public boolean isValid()
{
	if(this.size()!=5)
	{
		return false;
	}
	this.sort();
 if(getCard(0).getRank()==getCard(3).getRank())
 {
	
		if(getCard(0).getRank()==getCard(1).getRank()&&getCard(0).getRank()==getCard(2).getRank()&&getCard(0).getRank()==getCard(3).getRank())
		{
			
				return true;
			}
 }
 else if (getCard(1).getRank()==getCard(4).getRank())
 {
	 if((getCard(1).getRank()==getCard(2).getRank()&&getCard(1).getRank()==getCard(3).getRank()&&getCard(1).getRank()==getCard(4).getRank()))
		 
			 {
		 return true;
			 }
			
			}return false;
 }
 
	 /**
	 * return Hand#getType()
	 */
	public String getType()
	    {
	            return "Quad";
	        }
	 /**
	 * return Hand#getTopCard()
	 */
	public Card getTopCard()
	 {
			this.sort();
			 if(getCard(0).getRank()==getCard(3).getRank())
			 {
				 	if(this.getCard(0).compareTo(this.getCard(1))==1&&this.getCard(0).compareTo(this.getCard(2))==1&&this.getCard(0).compareTo(this.getCard(3))==1)
				 	{
				 		return getCard(0);
				 	}
				 	else if(this.getCard(1).compareTo(this.getCard(0))==1&&this.getCard(1).compareTo(this.getCard(2))==1&&this.getCard(1).compareTo(this.getCard(2))==1)
				 	
				 	{
				 		return getCard(1);
				 	}
				 	else if(this.getCard(2).compareTo(this.getCard(0))==1&&this.getCard(2).compareTo(this.getCard(1))==1&&this.getCard(2).compareTo(this.getCard(3))==1)
				 		{
				 		return getCard(2);
				 }
			 else {
				 return getCard(3);
			 }
			 }
			 else
			 {
				 if(this.getCard(4).compareTo(this.getCard(1))==1&&this.getCard(4).compareTo(this.getCard(2))==1&&this.getCard(4).compareTo(this.getCard(3))==1)
				 	{
				 		return getCard(4);
				 	}
				 	else if(this.getCard(1).compareTo(this.getCard(4))==1&&this.getCard(1).compareTo(this.getCard(2))==1&&this.getCard(1).compareTo(this.getCard(2))==1)
				 	
				 	{
				 		return getCard(1);
				 	}
				 	else if(this.getCard(2).compareTo(this.getCard(4))==1&&this.getCard(2).compareTo(this.getCard(1))==1&&this.getCard(2).compareTo(this.getCard(3))==1)
				 		{
				 		return getCard(2);
				 }
			 else {
				 return getCard(3);
			 }
			 }
				 }
			 }//ff
