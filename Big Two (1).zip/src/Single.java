/**
 * This class checks if single is the valid hand or not.
 * @author trishagupta
 *
 */
public class Single extends Hand
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Single(CardGamePlayer player, CardList cards)
    {
        super(player, cards);
    }
   
    /**
     * return Hand#getType()
     */
    public String getType()
    {
            return "Single";
        }
/**
 * return Hand#isValid()
 */
public boolean isValid()
{
    if(this.size()==1)
    	
    return true;
    return false;
}
/**
 * return Hand#getTopCard()
 */
public Card getTopCard()
{
	return getCard(0);
}
}//ff