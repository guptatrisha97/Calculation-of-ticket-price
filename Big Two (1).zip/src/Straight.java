
/**
 * This class checks if straight is the valid hand or not
 * @author trishagupta
 *
 */
public class Straight extends Hand
{
    public Straight(CardGamePlayer player, CardList cards) {
		super(player, cards);
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** 
	 * return Hand#isValid()
	 */
	public boolean isValid()//fine?
    {
		if(this.size()!=5)
		{
			return false;
		}
for (int x=0; x<4; x++) 
        {
	
	if((getCard(x).getRank()-getCard(x+1).getRank()!=-1)&&(getCard(x).getRank()-getCard(x+1).getRank()!=12))
            {
return false;
            }}
	 return true;
		
            
		        }
		
        
    /**
     * return Hand#getType()
     */
    public String getType()
    {
            return "Straight";}
        
/**
 * return Hand#getTopCard()
 */
public Card getTopCard()
{
	this.sort();
	return getCard(4);
}}
//ff
