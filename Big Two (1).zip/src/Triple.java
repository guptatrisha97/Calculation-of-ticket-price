/**
 * This class checks if triple is the valid hand or not
 * @author trishagupta
 *
 */
public class Triple extends Hand
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Triple(CardGamePlayer player, CardList cards)
    {
        super(player, cards);
    }
   
   
/**
 * return Hand#isValid()
 */
public boolean isValid()
{
    if(this.size()==3)
    {
    	
    		if(getCard(0).getRank()==getCard(1).getRank()&&getCard(0).getRank()==getCard(2).getRank())
    		{
    			
    				return true;
    			}
    			else
    			{
    				return false;
    			}
    			}
    
    else {return false;
    }
    		}
/** 
 * return Hand#getType()
 */
public String getType()
{
        return "Triple";
    }

/** 
 * return Hand#getTopCard()
 */
public Card getTopCard()
{
	if(this.getCard(0).compareTo(this.getCard(1))==1&&this.getCard(0).compareTo(this.getCard(2))==1)
	{
		return getCard(0);
	}
	else if(this.getCard(1).compareTo(this.getCard(0))==1&&this.getCard(1).compareTo(this.getCard(2))==1)
	{
		return getCard(1);
	}
	else
		return getCard(2);
}
}//ff
			