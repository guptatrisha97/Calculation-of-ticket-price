/**
 * This class checks if the hand is valid for pair A pair hand consists of two cards with the same rank.
 * @author trishagupta
 *
 */
public class Pair extends Hand
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param player: the player who is playing
	 * @param cards: the cards he has
	 */
	public Pair(CardGamePlayer player, CardList cards)
    {
        super(player, cards);
    }
   
  
/**
 * return Hand#isValid()
 */
public boolean isValid()
{
    if(this.size()!=2)
    {
    	return false;
    }
    
  		if(getCard(0).getRank()==getCard(1).getRank())
		{
				return true;
			}
			
			
				return false;
			}
			


/** (non-Javadoc)
 * @see Hand#getType()
 */
public String getType()
{
        return "Pair";
    }

/**
 * return Hand#getTopCard()
 */
public Card getTopCard()
{
	if(this.getCard(0).compareTo(this.getCard(1))==1)
	{
		return getCard(0);
	}
	else
	{
		return getCard(1);
	}
}
			
		}//ff
