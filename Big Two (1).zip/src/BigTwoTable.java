import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.awt.event.*;
import javax.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

/**
 * @author trishagupta 
 * 
 * The BigTwoTable class implements the CardGameTable
 *  interface. It is used to build a GUI for the Big Two card game and
 *   handle all user actions.
 */

public class BigTwoTable implements CardGameTable {

	/**
	 * @param game:
	 *            cardgame object
	 */
	private JMenuItem item1 = new JMenuItem("Connect");
	private JMenuItem item = new JMenuItem("Clear");

	private JMenuItem item2 = new JMenuItem("Quit");
	private JFrame f;// the main gui frame
	private JPanel p, q;// the panel with background
	private JButton b, c;// the buttons for play and pass
	private JLabel l, l2, l3, l4;// the labels for player names
	private BigTwoClient game; // a card game associates with this table.
	boolean[] selected;// a boolean array indicating which cards are being
						// selected.
	int activePlayer; // an integer specifying the index of the active player.
	JFrame frame; // the main window of the application.
	JPanel bigTwoPanel; // a panel for showing the cards of each player and the
						// card played on the table.
	JButton playButton; // a “Play” button for the active player to play the
						// selected cards.
	JButton passButton; // a “Pass” button for the active player to pass his/her
						// turn to the next player
	JTextArea msgArea; // a text area for showing the current game status as
	BigTwoClient cl;			// well as end of game messages.
	Image cardBackImage; // an image for the backs of the cards.
	Image[] avatars; // an array storing the images for the avatars.
	Image[][] cardImages; // a 2D array storing the images for the faces of the
	Panel panell;					// cards.
	JTextArea incoming; // for showing messages
	JTextField outgoing; // for user inputs
boolean dis=true;
	/**
	 * @param game: constructor to set the bigtwo table
	 */
	public BigTwoTable(BigTwoClient game)// a constructor for creating a
										// BigTwoTable.
	{
		 
		this.game = game;
		f = new JFrame("Big Two");

		f.setSize(900, 700);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		q = new JPanel();// for buttons
		q.setBackground(Color.WHITE);
		b = new JButton("Play");
		b.addActionListener(new PlayButtonListener());
		c = new JButton("Pass");
		c.addActionListener(new PassButtonListener());
		q.add(b);
		q.add(c);
		f.add(q, BorderLayout.SOUTH);
		
		JPanel panell=new JPanel();
		panell.setLayout(new BoxLayout(panell, BoxLayout.Y_AXIS));
		msgArea = new JTextArea(47, 25);
		msgArea.setLineWrap(true);
		msgArea.setEditable(false);

		JScrollPane scroller = new JScrollPane(msgArea);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS); 
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		incoming = new JTextArea(50, 25);
		incoming.setLineWrap(true);
		incoming.setWrapStyleWord(true);
		incoming.setEditable(false);
		JScrollPane qScroller = new JScrollPane(incoming);
		qScroller.setVerticalScrollBarPolicy(
				ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				qScroller.setHorizontalScrollBarPolicy(
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
				

		outgoing = new JTextField(5);
		outgoing.addActionListener(new MessageListener());
		outgoing.addKeyListener(new FieldKeyListener());

		JLabel sendButton = new JLabel("Message");		
		panell.add(scroller);		
		panell.add(qScroller);
		panell.add(outgoing, BorderLayout.EAST);
		panell.add(sendButton,BorderLayout.WEST);

		f.add(panell, BorderLayout.EAST);

		Image cardsy;
		f.setVisible(true);
		cardImages = new Image[4][13];
		avatars = new Image[4];
		bigTwoPanel = new BigTwoPanel();
		
		
		bigTwoPanel.setBackground(Color.GREEN.darker());
		f.add(bigTwoPanel, BorderLayout.WEST);
	
		bigTwoPanel.setLayout(new BoxLayout(bigTwoPanel, BoxLayout.X_AXIS));
		bigTwoPanel.setPreferredSize(new Dimension(600, 600));
		bigTwoPanel.addMouseListener(new BigTwoPanel());
		f.setVisible(true);
		JMenuBar menubar = new JMenuBar();
		JMenu menu = new JMenu("Game");
		JMenu menu2=new JMenu("Message");
		menubar.add(menu);
		menubar.add(menu2);
		f.setJMenuBar(menubar);
		item.addActionListener(new ClearMenuItemListener());
		item2.addActionListener(new QuitMenuItemListener());
		menu.add(item1);
		menu.add(item2);
		menu2.add(item);
		
		f.setVisible(true);
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 13; j++) {
				cardsy = new ImageIcon(getClass().getResource("cards/" + j + "" + i + ".gif")).getImage();
				cardImages[i][j] = cardsy;
			}
		}
		cardBackImage = new ImageIcon(getClass().getResource("b.gif")).getImage();

		selected = new boolean[13];
		for (int j = 0; j < 13; j++) {
			selected[j] = false;
		}
	}

	/**
	 * @param activePlayer:
	 *            the player who's playing currently
	 */
	public void setActivePlayer(int activePlayer) // a method for setting the
										// index of the active
													// player
	{
		this.activePlayer = activePlayer;
	}

	/**
	 * @return the selected indices of cards
	 */
	public int[] getSelected()// a method for getting an array of indices of the
								// cards selected.
	{
		int size = 0; // Number of selected cards.
		for (int i = 0; i < 13; i++) {
			if (selected[i]) {
				size += 1;
			}
		}
		int[] cards = new int[size]; // Array to store indices.
		int count = 0;
		for (int i = 0; i < 13; i++) {
			if (selected[i]) {
				cards[count] = i;
				count += 1;
			}
		}
		if (size == 0) {
			return null;
		} else {
			return cards;
		}
	}

	/**
	 * reset selected cards
	 */
	public void resetSelected() // a method for resetting the list of selected
								// cards.
	{
		for (int i = 0; i < 13; i++) {
			selected[i] = false;
		}
	}

	/**
	 * calls repaint
	 */
	public void repaint() // a method for repainting the GUI.
	{
		if(game.getPlayerID()!=game.getCurrentIdx())
		{
			this.disable();
		}
		else
		{
			this.enable();
		}
		resetSelected();
		f.repaint();
	}
	public void setExistence(int i)
	{
		
	}
	/**
	 * @param msg:
	 *            the msg on text area
	 */
	public void printMsg(String msg) // a method for printing the specified
										// string to the message area of the
										// GUI.
	{
		msgArea.append(msg);
		msgArea.append("\n");
		msgArea.setCaretPosition(msgArea.getDocument().getLength());
	}
	public void printChatMsg(String msg)
	{
		incoming.append(msg);
		incoming.append("\n");
		incoming.setCaretPosition(incoming.getDocument().getLength());
	}
	/**
	 * clears msg area
	 */
	public void clearMsgArea() // a method for clearing the message area of the
								// GUI.
	{
		msgArea.removeAll();
	}
	public void clearChatMsgArea()
	{
		incoming.setText("");

	}

	/**
	 * a method for resetting the GUI.
	 */
	public void reset() // a method for resetting the GUI.
	{
		resetSelected();
		clearMsgArea();
		enable();
	}

	/**
	 * a method for enabling user interactions with the GUI
	 */
	public void enable() // a method for enabling user interactions with the GUI
	{
		b.setEnabled(true);
		c.setEnabled(true);
		bigTwoPanel.setEnabled(true);
		dis=true;
	}

	/**
	 * method for disabling user interactions with the GUI.
	 */
	public void disable() // a method for disabling user interactions with the
							// GUI.
	{
		b.setEnabled(false);
		c.setEnabled(false);
		dis=false;
		bigTwoPanel.setEnabled(false);
	}

	/**
	 * @author trishagupta 
	 * inner class big two panel:an inner class that extends
	 *         the JPanel class and implements the MouseListener interface.
	 *         Overrides the paintComponent() method inherited from the JPanel
	 *         class to draw the card game table. Implements the mouseClicked()
	 *         method from the MouseListener interface to handle mouse click
	 *         events.
	 */
	public class BigTwoPanel extends JPanel implements MouseListener {
		// private Image image;private JLabel label;

		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g) // set the card table for
												// gameplay
		{
		    super.paintComponent(g);
			g.setColor(Color.BLACK.darker());
			g.drawString(game.getPlayerList().get(0).getName(), 8, 30);
			Image image = new ImageIcon(getClass().getResource("batman.jpg")).getImage();
			g.drawImage(image, 0, 30, this);
			g.drawLine(0, 120, 900, 120);

			if (activePlayer != 0) {
				for (int i = 0; i < game.getPlayerList().get(0).getCardsInHand().size(); i++) {
					// image=new
					// ImageIcon(getClass().getResource("b.gif")).getImage();
					g.drawImage(cardBackImage, 100 + 30 * i, 20, this);
				}
			}

			else {
				for (int i = 0; i < game.getPlayerList().get(0).getCardsInHand().size(); i++) {
					if (selected[i] == false)
						g.drawImage(
								cardImages[game.getPlayerList().get(0).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(0).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 20, this);
					else
						g.drawImage(
								cardImages[game.getPlayerList().get(0).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(0).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 10, this);
				}
			}

			g.drawString(game.getPlayerList().get(1).getName(), 8, 140);
			image = new ImageIcon(getClass().getResource("flash_72.png")).getImage();
			g.drawImage(image, 0, 140, this);
			g.drawLine(0, 230, 900, 230);
			if (activePlayer != 1) {
				for (int i = 0; i < game.getPlayerList().get(1).getCardsInHand().size(); i++) {
					image = new ImageIcon(getClass().getResource("b.gif")).getImage();
					g.drawImage(image, 100 + 30 * i, 130, this);
				}
			} else {
				for (int i = 0; i < game.getPlayerList().get(1).getCardsInHand().size(); i++) {
					if (selected[i] == false)
						g.drawImage(
								cardImages[game.getPlayerList().get(1).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(1).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 130, this);
					else
						g.drawImage(
								cardImages[game.getPlayerList().get(1).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(1).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 120, this);
				}
			}

			g.drawString(game.getPlayerList().get(2).getName(), 8, 250);
			image = new ImageIcon(getClass().getResource("green_lantern_72.png")).getImage();
			g.drawImage(image, 0, 250, this);
			g.drawLine(0, 340, 700, 340);
			if (activePlayer != 2) {
				for (int i = 0; i < game.getPlayerList().get(2).getCardsInHand().size(); i++) {
					image = new ImageIcon(getClass().getResource("b.gif")).getImage();
					g.drawImage(image, 100 + 30 * i, 240, this);
				}
			} else {
				for (int i = 0; i < game.getPlayerList().get(2).getCardsInHand().size(); i++) {
					if (selected[i] == false)
						g.drawImage(
								cardImages[game.getPlayerList().get(2).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(2).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 240, this);
					else
						g.drawImage(
								cardImages[game.getPlayerList().get(2).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(2).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 230, this);
				}
			}

			g.drawString(game.getPlayerList().get(3).getName(), 8, 360);
			image = new ImageIcon(getClass().getResource("superman_72.png")).getImage();
			g.drawImage(image, 0, 360, this);
			g.drawLine(0, 450, 700, 450);
			if (activePlayer != 3) {

				for (int i = 0; i < game.getPlayerList().get(3).getCardsInHand().size(); i++) {
					image = new ImageIcon(getClass().getResource("b.gif")).getImage();
					g.drawImage(image, 100 + 30 * i, 350, this);
				}
			} else {
				for (int i = 0; i < game.getPlayerList().get(3).getCardsInHand().size(); i++) {
					if (selected[i] == false)
						g.drawImage(
								cardImages[game.getPlayerList().get(3).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(3).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 350, this);
					else
						g.drawImage(
								cardImages[game.getPlayerList().get(3).getCardsInHand().getCard(i).getSuit()][game
										.getPlayerList().get(3).getCardsInHand().getCard(i).getRank()],
								100 + 30 * i, 340, this);
				}
			}
			if(game.getHandsOnTable().size()!=0)
			{

			Hand lastHand = game.getHandsOnTable().get(game.getHandsOnTable().size() - 1);
			g.drawString("Played by "+lastHand.getPlayer().getName(), 8, 470);
			for (int i = 0; i < lastHand.size(); i++) 
			{
				g.drawImage(
						cardImages[lastHand.getCard(i).getSuit()]
								[lastHand.getCard(i).getRank()],
						100 + 30 * i, 480, this);
			}}
			else
				g.drawString("No cards played", 8, 470);

		}

		/**
		 * @param e:mouseclick
		 *            event
		 */
		public void mouseClicked(MouseEvent e)
		{
			if(dis== true){
			int x = e.getX();
			int y = e.getY();
			//System.out.println(x + " " + y);
			int row = activePlayer;
			int x1 = 100;
			int x2 = 190;
			int col = 130;
			int y1 =  (row * 110)+10;
			int y2 = 20 + ((row * 110) + 97);
			int size = game.getPlayerList().get(activePlayer).getNumOfCards();
			for (int i = size - 1; i >= 0; i--) {
				//System.out.println(y1 + "PP" + y2);
				if (selected[i]==false && y >= y1+10 && y <= y2 &&( x >= (col + (i - 1) * 30)) && (x <= (col + (i-1) * 30) + 73)) {
					// if (i == size - 1) {
					//System.out.println(col + (i - 1) * 30 + " {{" + col + i * 20 + 53);

					selected[i] = true;
					f.repaint();
					return;
					// }
				}
				if (selected[i]==true && y >= y1 && y <= y2-10 && x >= (col + (i - 1) * 30) && x < (col + (i-1) * 30) + 73) {
					// if (i == size - 1) {
					//System.out.println(col + (i - 1) * 30 + " {{" + col + i * 20 + 53);

					selected[i] = false;
					f.repaint();
					return;
					// }
				}
				
			}
			}
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mousePressed(MouseEvent e) {
		}
	}

	/**
	 * @author trishagupta 
	 * an inner class that implements the ActionListener
	 *         interface. Implements the actionPerformed() method from the
	 *         ActionListener interface to handle button-click events for the
	 *         “Play” button.
	 *
	 */
	public class PlayButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (getSelected() != null&&game.endOfGame()!=true) {

				game.makeMove(activePlayer, getSelected());

			} 
		
			else
				printMsg("Please select a card to play, else pass!\n");
		}
	}

	/**
	 * @author trishagupta 
	 * an inner class that implements the ActionListener
	 *         interface. Implements the actionPerformed() method from the
	 *         ActionListener interface to handle button-click events for the
	 *         “Pass” button.
	 *
	 */
	public class PassButtonListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			game.makeMove(activePlayer, null);

		}
	}

	/**
	 * @author trishagupta 
	 * an inner class that implements the ActionListener
	 *         interface. Implements the actionPerformed() method from the
	 *         ActionListener interface to handle menu-item-click events for the
	 *         “Restart” menu item.
	 */
	class ConnectMenuItemListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			game.makeConnection();
			
			
			// TODO Auto-generated method stub
			/*BigTwoDeck de = new BigTwoDeck();
			de.shuffle();
			//BigTwo game = new BigTwo();
			game.start(de);*/
			

		}
	}
	
	/**
	 * @author trishagupta
	 * inner class to send msgs in the chatbox
	 *
	 */
	class MessageListener implements ActionListener
	{
		String msg;			//BigTwoClient ob=new BigTwoClient();

		public void actionPerformed(ActionEvent e) {
	        String text = outgoing.getText();

			printChatMsg(text);
		}
	}
	/*public class IncomingReader implements Runnable 
	{
		public void run() {
			String message;
			try {
				while ((message = reader.readLine()) != null) {
					System.out.println("read " + message);
					incoming.append(message + "\n");
				}
				} catch (Exception ex) {
				ex.printStackTrace();
				}
				}
			}
	public class SendButtonListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent event) {
		try {
			BigTwoClient ob=new BigTwoClient();
			ob.writer.println(outgoing.getText());
		writer.flush();
		} catch (Exception ex) {
		ex.printStackTrace();
		}
		outgoing.setText("");
		outgoing.requestFocus();
		}}*/
	/**
	 * @author trishagupta 
	 * an inner class that implements the ActionListener
	 *         interface. Implements the actionPerformed() method from the
	 *         ActionListener interface to handle menu-item-click events for the
	 *         “Quit” menu item.
	 */
	public void quit()
	{
		System.exit(0);

	}
	/**
	 * @author trishagupta
	 * innerclass to clear the chatbox
	 *
	 */
	class ClearMenuItemListener implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e)
		{
			clearMsgArea();
			clearChatMsgArea();
		}
	}
	/**
	 * @author trishagupta
	 * inner class to quit the game
	 *
	 */
	class QuitMenuItemListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.exit(0);
		}

	}
	/**
	 * @author trishagupta
	 * inner class implementing key listener 
	 *
	 */
	class FieldKeyListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				((BigTwoClient)game).sendMessage(new CardGameMessage(CardGameMessage.MSG,-1,outgoing.getText()));
				outgoing.setText("");
			}
		}

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
}
//final
