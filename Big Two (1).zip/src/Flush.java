/**
 * @author trishagupta
 *
 */
public class Flush extends Hand
{
         /**
         * @param player
         * @param cards
         */
        public Flush(CardGamePlayer player, CardList cards) {
		super(player, cards);
		// TODO Auto-generated constructor stub
	}
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		/**
		 * return Hand#isValid()
		 */
		public boolean isValid()
         {
			if(this.size()==5)
			{          int counter = 0;

for (int x=0; x<4; x++)

      {
            if ( getCard(x).getSuit() != getCard(x+1).getSuit() )

                return false;
                else {
                    counter++;
                     if(counter == 4){
            return true;
        }
                }
                
        }
       
			}return false;
         }
    /**
     * return Hand#getType()
     */
    public String getType()
    {

      
            return "Flush";
        }
    public Card getTopCard()
    {
    	this.sort();
    	return getCard(4);
    }}
//ff