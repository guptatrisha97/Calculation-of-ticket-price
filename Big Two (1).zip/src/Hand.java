/**
 * The Hand class is a subclass of the CardList class, and is used to model a hand of cards. 
 * @author trishagupta
 *
 */
public abstract class Hand extends CardList
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private CardGamePlayer player;//the player who plays this hand.

	/**
	 * a constructor for building a hand with the specified player and list of cards.
	 * @param player
	 * @param cards
	 */
	public Hand(CardGamePlayer player, CardList cards)
    {
		this.player=player;
		for(int i=0;i<cards.size();i++)
		{
			this.addCard(cards.getCard(i));
		}
		this.sort();
		
    }

    /**
     * a method for retrieving the player of this hand.
     * @return player
     */
    public CardGamePlayer getPlayer()
    {
        return this.player;
    }
    /**
     * a method for retrieving the top card of this hand.
     * @return getTopCard
     */
    public Card getTopCard()
    {
        return this.getCard(this.size()-1);
    }
    /**a method for checking if this hand beats a specified hand.
     * @param hand
     * @return if it beats or not
     */
    public boolean beats(Hand hand)
	{			
    	    		if(this.size() == 1 || this.size() == 2 || this.size() == 3)//checks for pair, single and triple
    		{if(this.size() == hand.size() && this.getTopCard().compareTo(hand.getTopCard()) == 1 && this.isValid())
    				return true;
    			else
    				return false;
    }
    		else
    		{
    	if(this.getType()=="StraightFlush")//checks for straightflush
    			{
    		if(this.size() == hand.size())
    				{
    	if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())==1)
    		return true;
    	else if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())!=1)
    	return false;
    	else if(this.getType()!=hand.getType())
    					{
    						return true;
    					}
    					
    				}
    				
    				else
    					return false;
    			}
    			
    			else if(this.getType()=="Straight")//checks for straight
    			{
    				if(this.size() == hand.size())
    				{
    			if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())==1)
    			return true;
    		else if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())!=1)
    		return false;
    					else if(this.getType()!=hand.getType())
    					{
    							return false;
    					}
    					
    				}
    				
    		else
    		return false;
    			}
    			
    	else if(this.getType()=="Quad")//checks for quad
    			{
    	if(this.size() == hand.size())
    				{
    		if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())==1)
    			return true;
    else if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())!=1)
    						return false;
 					else if(this.getType()!=hand.getType())
    					{
    						if(hand.getType()!="Straight Flush")
    							return true;
    						else
    							return false;
    					}
    					
    				}
    				
    				else
    					return false;
    			}
    			
    			else if(this.getType()=="FullHouse")//checks for fullhouse
    			{
    				if(this.size() == hand.size())
    				{
    					if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())==1)
    						return true;
    					else if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())!=1)
    						return false;
    					else if(this.getType()!=hand.getType())
    					{
    						if(hand.getType()!="Straight Flush" && hand.getType()!="Quad")
    							return true;
    						else
    							return false;
    					}	
    				}
    				
    				else
    					return false;
    			}
    			
    			else if(this.getType()=="Flush")
    			{
    				if(this.size() == hand.size())
    				{
    					if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())==1)
    						return true;
    					else if(this.getType() == hand.getType() && this.getTopCard().compareTo(hand.getTopCard())!=1)
    						return false;
    					else if(this.getType()!=hand.getType())
    					{
    						if(hand.getType()=="Straight")
    							return true;
    						else
    							return false;
    					}
    					
    				}
    				
    				else
    					return false;
    			}
    			
    		}
    		
    		return false;
    		
    	}
    public abstract boolean isValid();//a method for checking if this is a valid hand.
    public abstract String getType() ;//a method for returning a string specifying the type of this hand.
}
//ff
            
            
    