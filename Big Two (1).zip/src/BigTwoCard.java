/**
 * The BigTwoCard class is a subclass of the Card class, and is used to model a card used in a Big Two card game.
 * @author trishagupta
 *
 */
public class BigTwoCard extends Card
{
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/**
 * a constructor for building a card with the specified suit and rank. 
 * @param suit
 * @param rank
 */
public BigTwoCard(int suit, int rank)
   {
       super(suit, rank);
       
   }
    /**
     * a method for comparing this card with the specified card for order.
     * @param card
     * @return comparison result
     */
    public int compareTo(Card card)
    {
            if(this.rank==1)//compares for rank
            {
            	if(card.rank ==1)
            	{
            	if (this.suit > card.suit) {
        			return 1;
        		} else if (this.suit < card.suit)//compares for suit 
        			{
        			return -1;
        		}
            	}
                return 1;
            }
            if(card.rank ==1)
            	return -1;
            
            
             if(this.rank==0)
            {
            	if(card.rank ==1)
                	return -1;
            	if(card.rank ==0)
            	{
            	if (this.suit > card.suit) {
        			return 1;
        		} else if (this.suit < card.suit) {
        			return -1;
        		}
            	}
                return 1;
            }
             if(card.rank ==0)
            	 return -1;
         
            
             if (this.rank > card.rank) {
			return 1;
		} else if (this.rank < card.rank) {
			return -1;
		} else if (this.suit > card.suit) {
			return 1;
		} else if (this.suit < card.suit) {
			return -1;
		} else {
			return 0;
		}
	}
    }//ff