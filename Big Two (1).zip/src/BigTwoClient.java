import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JOptionPane;

 
/**
 * @author trisha gupta
 * The BigTwoClient class implements the CardGame interface and NetworkGame interface. It
  is used to model a Big Two card game that supports 4 players playing over the internet.
 *
 */
public class BigTwoClient implements CardGame, NetworkGame 
{
	private int numOfPlayers; //– an integer specifying the number of players.
	private Deck deck; //– a deck of cards.
	private ArrayList<CardGamePlayer> playerList = new ArrayList<CardGamePlayer>();// list of players
	private ArrayList<Hand> handsOnTable; //– a list of hands played on the table.
	private int playerID; //– an integer specifying the playerID (i.e., index) of the local player. String playerName – a string specifying the name of the local player.
	private String serverIP; //– a string specifying the IP address of the game server.
	private int serverPort; //– an integer specifying the TCP port of the game server.
	private Socket sock; //– a socket connection to the game server.
	private ObjectOutputStream oos; //– an ObjectOutputStream for sending messages to the server.
	private int currentIdx ;//– an integer specifying the index of the player for the current turn.
	private BigTwoTable table ;//– a Big Two table which builds the GUI for the game and handles all user actions.
	private String playerName;
	private ObjectInputStream ois;
private NetworkGame net;
	/**
	 * a constructor for creating a Big Two client.
	 */
	public BigTwoClient() //– a constructor for creating a Big Two client.
	{
		playerList = new ArrayList<CardGamePlayer>();
		for (int i = 0; i < 4; i++)
			playerList.add(new CardGamePlayer());
		handsOnTable = new ArrayList<Hand>();
		table = new BigTwoTable(this);
		table.disable();
		table.repaint();
		playerName = (String) JOptionPane.showInputDialog("Please enter your name: ");
		if (playerName == null || playerName.trim().isEmpty() == true)
			playerName = "Default_name";
		makeConnection();
		table.repaint();
	}
	 /**
	 * @author trishagupta
	 * inner class to run server
	 *
	 */
	class ServerHandler implements Runnable
	{
		public void run()
		{		

			CardGameMessage message=null;
			try
			{
				while ((message = (CardGameMessage) ois.readObject()) != null) {
					parseMessage(message);
					System.out.println("Receiving messages~");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			table.repaint();
		}
	}

	/**
	 *  a method for getting the number of players.
	 * @return CardGame#getNumOfPlayers()
	 */
	public int getNumOfPlayers() //– a method for getting the number of players.
	{
		return playerList.size();
	}
	/** 
	 * a method for getting the deck of cards being used.
	 * @return CardGame#getDeck()
	 */
	/** a method for getting the deck of cards being used.
	 * @return CardGame#getDeck()
	 */
	public Deck getDeck() //– a method for getting the deck of cards being used.
	{
	return deck;	
	}
	/**a method for getting the list of players
	 * @return CardGame#getPlayerList()
	 */
	public ArrayList<CardGamePlayer> getPlayerList() //– a method for getting the list of players.
	{
	return playerList;	
	}
	/**a method for getting the list of hands played on the table.
	 * @see CardGame#getHandsOnTable()
	 */
	public ArrayList<Hand> getHandsOnTable() //– a method for getting the list of hands played on the table.
	{
		return handsOnTable;
	}
	/** a method for getting the index of the player for the current turn.
	 * @return CardGame#getCurrentIdx()
	 */
	public int getCurrentIdx() //– a method for getting the index of the player for the current turn.
	{
		return currentIdx;
	}
	/** a method for starting/restarting the game with a given shuffled deck of cards. 
	 * 
	 */
	public void start(Deck deck) //– a method for starting/restarting the game with a given shuffled deck of cards. 
	{
		//ArrayList<Hand>
		
				handsOnTable = new ArrayList<Hand>();
				int y = 0;
				for(int i = 0; i < 4; i++)
				{
					playerList.get(i).removeAllCards();
					for(int k = 0; k < 13; k++)
					{
						playerList.get(i).addCard(deck.getCard(y+i+k)); //Card Distribution
					}
					y += 12;
					playerList.get(i).sortCardsInHand();
				}
				currentIdx = -1;
				Card c = new Card(0,2); //3 of diamonds
				
				for(int i = 0; i < 4; i++)
				{
					if(playerList.get(i).getCardsInHand().contains(c))
					{
						//bigtwoconsole.setActivePlayer(i);
						//table.setActivePlayer(i); //Active player set
						currentIdx = i;
						//table.printMsg("Player"+currentIdx);
					}
				}
				table.enable();
				table.repaint();		

				table.setActivePlayer(playerID);
if(currentIdx!=getPlayerID())
	table.disable();
else
	table.enable();
table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");
				table.repaint();		

			}
	
	/** a method for making a move by a player with the specified playerID using the cards specified by the list of indices. 
	 * 
	 */
	public void makeMove(int playerID, int[] cardIdx) // – a method for making a move by a player with the specified playerID using the cards specified by the list of indices. 
	{
		CardGameMessage msg = new CardGameMessage(CardGameMessage.MOVE, -1, cardIdx);
		sendMessage(msg);


	}
	/**a method for checking a move made by a player. This method should be called from the parseMessage() method from the NetworkGame interface when a message of the type MOVE is received from the game server. The playerID and data in this message give the playerID of the player who makes the move and a reference to a regular array of integers specifying the indices of the selected cards, respectively. These are used as the arguments in calling the checkMove() method.
	{
	 * @see CardGame#checkMove(int, int[])
	 */
	public void checkMove(int playerID, int[] cardIdx) //– a method for checking a move made by a player. This method should be called from the parseMessage() method from the NetworkGame interface when a message of the type MOVE is received from the game server. The playerID and data in this message give the playerID of the player who makes the move and a reference to a regular array of integers specifying the indices of the selected cards, respectively. These are used as the arguments in calling the checkMove() method.
	{
		//table.printMsg("Player "+currentIdx);
		//int prevplayer = -1; //Previous player index
				 boolean game = false; //Variable for game end
					boolean flag = true; //variable for legal hand
					
						if(flag)
						{
							System.out.println();
						}
						int[] choices = cardIdx; //Array to store the inputs by the user.
						if(choices != null)
						{
							CardList p = playerList.get(currentIdx).play(choices); //object of cardlist to convert the array to cards.
							//table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");
							Hand h = composeHand(playerList.get(currentIdx), p); 
							if(handsOnTable.isEmpty())
							{
								if(h==null)
								{
									flag=false;
								}
								else if(h.contains(new Card(0,2)) && !h.getType().isEmpty())
								{
									flag = true;
									//table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");

								}
								else
								{
									flag = false;
								}
							}
							else if(h!=null)
							{
								if(this.getHandsOnTable().get(this.getHandsOnTable().size()-1).getPlayer() != this.getPlayerList().get(currentIdx))
								{

									//table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");

									flag = h.beats(handsOnTable.get(handsOnTable.size() - 1));
								}
								else
								{
									flag = true;
									//table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");

								}
							}
							else
							{
			flag=false;				}
							if(flag)
							{	
								
								//prevplayer = currentIdx;
								//System.out.println(p.size());
								for(int i = 0; i < p.size(); i++)
								{
									
									playerList.get(currentIdx).getCardsInHand().removeCard(p.getCard(i));
									if(playerList.get(currentIdx).getCardsInHand().isEmpty())
									{
										game = true;
										table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");

									}
								}
								//System.out.println("{"+h.getType()+"} " + h);
								table.printMsg("{"+h.getType()+"} " + h);
								
								table.printMsg(playerList.get((currentIdx+1)%4).getName()+"'s turn:");

								handsOnTable.add(h);
								currentIdx = (currentIdx+1)%4;
								//bigtwoconsole.setActivePlayer(currentIdx);
								//table.setActivePlayer(currentIdx);
								table.repaint();
								if(endOfGame()==true)
								{
									table.disable();
								table.printMsg("Game ends");
								String msg = "";
								for (int i = 0; i < 4; i++) {
									if (playerList.get(i).getNumOfCards() == 0)
										msg += "Winner: Player " + i + ": " + playerList.get(i).getName() + "\n";
									else
										msg += "Player " + i + ": " + playerList.get(i).getName() + " have " + playerList.get(i).getNumOfCards() + " cards in hand.\n";
								}
								msg += "Do you want to start a new game?\n";
								for (int i = 0; i < 4; i++)
									playerList.get(i).removeAllCards();
								int feedback = JOptionPane.showConfirmDialog(null, msg, "Game Result", JOptionPane.YES_NO_OPTION);
								if (feedback == 0) {
									
									sendMessage(new CardGameMessage(1, -1, this.getPlayerName()));
									sendMessage(new CardGameMessage(4, -1, null));
									playerList.get(this.getPlayerID()).removeAllCards();
									table.repaint();
								} else {
									
									table.quit();
						}
					}
								/*for(int i = 0; i < 4; i++)
								{
									if(getPlayerList().get(i).getCardsInHand().size() == 0)
									{
										//System.out.println("Player "+ i + " wins the game.");
										table.printMsg("Player "+ i + " wins the game.");
									}
									else
									{
										//System.out.println("Player " + i +" has " + getPlayerList().get(i).getCardsInHand().size() + " cards in hand.");
										table.printMsg("Player " + i +" has " + getPlayerList().get(i).getCardsInHand().size() + " cards in hand.");
										}}}*/
								
								return;
							}
							else
							{
								//System.out.println("Not a legal move!!!1");
								table.printMsg("Not a legal move!!!");
								table.repaint();

								return;
							}
						}
						else
						{
							if(!handsOnTable.isEmpty() && this.getHandsOnTable().get(this.getHandsOnTable().size()-1).getPlayer() != this.getPlayerList().get(currentIdx))
							{
								//table.printMsg(playerList.get((currentIdx)%4).getName()+"'s turn:");
								table.printMsg("{Pass}");
								
								currentIdx = (currentIdx+1)%4;
								table.printMsg(playerList.get(currentIdx).getName()+"'s turn:");

								//bigtwoconsole.setActivePlayer(currentIdx);
								//table.setActivePlayer(currentIdx);
								flag = true;
								table.repaint();
								return;
								
							}
				
							else
							{
								//System.out.println("Not a legal move!!!2");
								table.printMsg("Not a legal move!!!");
								
								flag = false;
								table.repaint();
								return;
							}/*
								if (endOfGame()) {
									// print the game result
									// if click OK then get ready for the next game
									String msg = "";
									for (int i = 0; i < 4; i++) {
										if (playerList.get(i).getNumOfCards() == 0)
											msg += "Winner: Player " + i + " " + playerList.get(i).getName() + "\n";
										else
											msg += "Player " + i + " " + playerList.get(i).getName() + "have " + playerList.get(i).getNumOfCards() + " cards in hand.\n";
									}
									msg += "Do you want to start a new game?\n";
									for (int i = 0; i < 4; i++)
										playerList.get(i).removeAllCards();
									int feedback = JOptionPane.showConfirmDialog(null, msg, "Game Result", JOptionPane.YES_NO_OPTION);
									if (feedback == 0) {
										
										sendMessage(new CardGameMessage(1, -1, this.getPlayerName()));
										sendMessage(new CardGameMessage(4, -1, null));
										playerList.get(this.getPlayerID()).removeAllCards();
										table.repaint();
									} else {
										
										table.quit();
							}
						}
							}*/
						}}
	/**
	 * @param player:CardGamePlayer player
	 * @param cards:CardList cards
	 * @return hand
	 */
	public Hand composeHand(CardGamePlayer player, CardList cards)
						{
							Hand h8 = new StraightFlush(player, cards);//checks if Straightflush is valid
							if (h8.isValid() == true)
								return h8;
							Hand h7 = new Quad(player, cards);//checks if quad is valid
							if (h7.isValid() == true)
								return h7;
							Hand h6 = new FullHouse(player, cards);//checks if fullhouse is valid
							if (h6.isValid() == true)
								return h6;
							Hand h5 = new Flush(player, cards);//checks if flush is valid
							if (h5.isValid() == true)
								return h5;
							Hand h4 = new Straight(player, cards);//checks if straight is valid
							if (h4.isValid() == true)
								return h4;
							Hand h3 = new Triple(player, cards);//checks if triple is valid
							if (h3.isValid() == true)
								return h3;
							Hand h2 = new Pair(player, cards);//checks if pair is valid
							if (h2.isValid() == true)
								return h2;
							Hand h1 = new Single(player, cards);//checks if single is valid
							if (h1.isValid() == true)
								return h1;
							return null;
						}
	
	/** a method for checking if the game ends.
	 * @return if game ended or not
	 */
	public boolean endOfGame() //– a method for checking if the game ends.
	{
		int c=0;
		for(int i = 0; i < 4; i++)
		{
			if(playerList.get(i).getCardsInHand().size() == 0)
			{
				c++;
				}
				}
				if(c>0)
				{
					return true;
				}
				else
					return false;
				}
	
/**a method for getting the playerID (i.e., index) of the local player.
 * @return playerID
 */
public int getPlayerID() //– a method for getting the playerID (i.e., index) of the local player.
{
	return playerID;
	
}
/** a method for setting the playerID (i.e., index) of the local player. This method should be called from the parseMessage() method when a message of the type PLAYER_LIST is received from the game server.
 * 
 */
public void setPlayerID(int playerID) //– a method for setting the playerID (i.e., index) of the local player. This method should be called from the parseMessage() method when a message of the type PLAYER_LIST is received from the game server.
{
	this.playerID=playerID;
}
/** a method for getting the name of the local player.
 * @return playerName
 */
public String getPlayerName() //– a method for getting the name of the local player.
{
	return playerName;
	}
/** a method for setting the name of the local player
 * 
 */
public void setPlayerName(String playerName) //– a method for setting the name of the local player
{
	playerList.get(playerID).setName(playerName);

}
/** a method for getting the IP address of the game server.
 * @return serverIP
 */
public String getServerIP() //– a method for getting the IP address of the game server.
{
	return serverIP;
}
/** a method for setting the IP address of the game server.
 * 
 */
public void setServerIP(String serverIP) //– a method for setting the IP address of the game server.
{
	this.serverIP=serverIP;
}
/** a method for getting the TCP port of the game server.
 * @return serverPort
 */
public int getServerPort() //– a method for getting the TCP port of the game server.
{
	return serverPort;
}
/** a method for setting the TCP port of the gameserver
 *
 */
public void setServerPort(int serverPort) //– a method for setting the TCP port of the gameserver
{
	this.serverPort=serverPort;
}
/** a method for making a socket connection with the game server. Upon successful connection, you should (i) create an ObjectOutputStream for sending messages to the game server; (ii) create a thread for receiving messages from the game server; (iii) send a message of the type JOIN to the game server, with playerID being -1 and data being a reference to a string representing the name of the local player; (iv) send a message of the type READY to the game server, with playerID and data being -1 and null, respectively.
 *
 */
public void makeConnection() //– a method for making a socket connection with the game server. Upon successful connection, you should (i) create an ObjectOutputStream for sending messages to the game server; (ii) create a thread for receiving messages from the game server; (iii) send a message of the type JOIN to the game server, with playerID being -1 and data being a reference to a string representing the name of the local player; (iv) send a message of the type READY to the game server, with playerID and data being -1 and null, respectively.
{
	//table.printMsg("UO");
	serverIP = "127.0.0.1";
	serverPort = 2396;
	try
	{
		sock = new Socket(this.serverIP, this.serverPort);
	}
	catch (Exception ex) 
	{
		ex.printStackTrace();
		}
	try 
	{
		oos = new ObjectOutputStream(sock.getOutputStream());
		ois = new ObjectInputStream(sock.getInputStream());
	} 
	catch (IOException e) 
	{
		e.printStackTrace();
	}
	Runnable threadJob = new ServerHandler();
	Thread myThread = new Thread(threadJob);
	myThread.start();
	sendMessage(new CardGameMessage(1, -1, this.getPlayerName()));
	sendMessage(new CardGameMessage(4, -1, null));
	table.repaint();
}

/** a method for parsing the messages received from the game server. This method should be called from the thread
 * 
 */
public synchronized void parseMessage(GameMessage message) //– a method for parsing the messages received from the game server. This method should be called from the thread
{
switch (message.getType()) {
	case CardGameMessage.PLAYER_LIST:
		setPlayerID(message.getPlayerID());
		this.playerID = message.getPlayerID();
		for (int i = 0; i < 4; i++) {
			if (((String[])message.getData())[i] != null) {
				this.playerList.get(i).setName(((String[])message.getData())[i]);
				
				//table.setExistence(i);
			}
		}
		this.table.repaint();
		break;
	case CardGameMessage.JOIN:
		this.playerList.get(message.getPlayerID()).setName((String)message.getData());
		table.setExistence(message.getPlayerID());
		this.table.repaint();
		table.printMsg("Player " + playerList.get(message.getPlayerID()).getName() + " joined the game!\n");
		break;
	case CardGameMessage.FULL:
		playerID = -1;
		table.printMsg("The game is now full, cannot join in. Please try next time!\n");
		table.repaint();
		break;
	case CardGameMessage.QUIT:
		table.printMsg("Player " + message.getPlayerID() + " " + playerList.get(message.getPlayerID()).getName() + " left the game.\n");
		this.playerList.get(message.getPlayerID()).setName("");
		//table.setNotExistence(message.getPlayerID());
		if (!this.endOfGame()) {
			table.disable();
			this.sendMessage(new CardGameMessage(4, -1, null));
			for (int i = 0; i < 4; i++)
				playerList.get(i).removeAllCards();
			table.repaint();
		}
		table.repaint();
		break;
	case CardGameMessage.READY:
		table.printMsg("Player " + message.getPlayerID() + " is ready now!\n");
		handsOnTable = new ArrayList<Hand>();
		table.repaint();
		break;
	case CardGameMessage.START:
		table.printMsg("Game is started now!\n\n");
		start((BigTwoDeck)message.getData());
		table.enable();
		table.repaint();
		break;
	case CardGameMessage.MOVE:
		checkMove(message.getPlayerID(), (int[])message.getData());
		table.repaint();
		break;
	case CardGameMessage.MSG:
		table.printChatMsg((String)message.getData());
		break;
	default:
		table.printMsg("Wrong message type: " + message.getType());
		table.repaint();
		break;
	}
	
}
	/*if(message.getType()==CardGameMessage.PLAYER_LIST)
	{
	this.playerID = message.getPlayerID();
	table.setActivePlayer(playerID);
	for (int i = 0; i < 4; i++) {
		if (((String[])message.getData())[i] != null) {
			this.playerList.get(i).setName(((String[])message.getData())[i]);
			//table.setExistence(i);
		}
	}
	this.table.repaint();

	if(message.getType()==CardGameMessage.JOIN)
	{
		this.playerList.get(message.getPlayerID()).setName((String)message.getData());
		//table.setExistence(message.getPlayerID());
		this.table.repaint();
		table.printMsg("Player " + playerList.get(message.getPlayerID()).getName() + " joined the game!\n");
		}
    if(message.getType()==CardGameMessage.FULL)
	{
		playerID = -1;
    	table.printMsg("Server full.Cannot join game. Please try later!\n");
		table.repaint();
	}
    
	if(message.getType()==CardGameMessage.READY)
	{
		table.printMsg("Player " + message.getPlayerID() + " is ready now!\n");
		handsOnTable = new ArrayList<Hand>();
		//System.out.println("ready received");
		table.repaint();
	}
	if(message.getType()==CardGameMessage.START)
	{
		start((BigTwoDeck)message.getData());
		System.out.println("Game started!\n\n");
		table.enable();
		table.repaint();
	}
	if(message.getType()==CardGameMessage.MOVE)
	{
		checkMove(message.getPlayerID(), (int[])message.getData());
		table.repaint();
	}
	if(message.getType()==CardGameMessage.MSG)
	{
		table.printChatMsg((String)message.getData());//or set msg???
	}	
	else
	{
		table.printMsg("Invalid message type: " + message.getType());
		table.repaint();
	}
}}*/
/** a method for sending the specified message to the game server. This method should be called whenever the client wants to communicate with the game server or other clients.
 * 
 */
public void sendMessage(GameMessage message) //– a method for sending the specified message to the game server. This method should be called whenever the client wants to communicate with the game server or other clients.
{		

	try
	{
		oos.writeObject(message);
		oos.flush();

		} catch (IOException e) { e.printStackTrace(); }
}

/**
 * @param args
 */
public static void main(String[] args) {
	BigTwoClient client = new BigTwoClient();
}
}
//final
	