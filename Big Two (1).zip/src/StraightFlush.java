/**
 * This class checks if straightflush is the valid hand or not
 * @author trishagupta
 *
 */
public class StraightFlush extends Hand
    {
        public StraightFlush(CardGamePlayer player, CardList cards) {
		super(player, cards);
		// TODO Auto-generated constructor stub
	}
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		/**
		 * return Hand#isValid()
		 */
		public boolean isValid()
        {
			if(this.size()!=5)
			{
				return false;
			}
			
		for (int x=0; x<4; x++) 
		        {
			
			if((getCard(x).getRank()-getCard(x+1).getRank()!=-1)&&(getCard(x).getRank()-getCard(x+1).getRank()!=12))
		            {
		return false;
		            }
								}
		        
	for (int x=0; x<4; x++)

    {
          if ( getCard(x).getSuit() != getCard(x+1).getSuit() )
          {
              return false;
                   
         }}
	
		return true;
		}
	      
/** 
 * return Hand#getType()
 */
public String getType()
{
        return "StraightFlush";
    }

/**
 * return Hand#getTopCard()
 */
public Card getTopCard()
{
	this.sort();
	return getCard(4);
}}//ff