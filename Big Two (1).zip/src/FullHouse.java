/**
 * @author trishagupta
 *
 */
public class FullHouse extends Hand
{
    public FullHouse(CardGamePlayer player, CardList cards) {
		super(player, cards);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** 
	 * return Hand#isValid()
	 */
	public boolean isValid()//how to check
    {
    
		if(this.size()!=5)
		{
			return false;
		}
			this.sort();

		
		if(this.getCard(0).rank==this.getCard(2).rank)
		{
	if(this.getCard(0).rank==this.getCard(1).rank&&this.getCard(0).rank==this.getCard(2).rank&&this.getCard(3).rank==this.getCard(4).rank)
			{
				return true;
			}}
		else if(this.getCard(0).rank==this.getCard(1).rank)
		{
			if(this.getCard(0).rank==this.getCard(1).rank&&this.getCard(2).rank==this.getCard(3).rank&&this.getCard(2).rank==this.getCard(4).rank)
			{	
	 return true;
			}}
		return false;
		}
				
    public String getType()
    {
            return "FullHouse";
        }

public Card getTopCard()
{
	this.sort();

	
	if(this.getCard(0).rank==this.getCard(2).rank)
	{
	return getCard(2);
	}
	else 
	{
		return getCard(4);
	}
}
	}//ff

